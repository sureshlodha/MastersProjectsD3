# d3PowerData
A visualization of the time series power consumption dataset for CMPS263
